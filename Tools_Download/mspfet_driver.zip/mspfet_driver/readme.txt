The Linux kernel shipped with Ubuntu version 8.04 has a version of the ti_usb_3410_5052
USB serial port driver that is slightly modified from the driver included in the standard
Linux kernel available from kernel.org.

The modified version of this driver shipped with Ubuntu Linux does not seem to work correctly
with the Texas Instruments MSP-FET430UIF emulator, or with the EZ430 developer's kit.  The
standard version of the driver does work with these devices (with a bit of extra configuration
required).							     

This directory contains the original driver copied streight out of the Linux kernel sources
downloaded from kernel.org (version 2.6.24.7).  It also includes a simple make file which 
allows this driver to be seperately compiled on an Ubuntu system.  The Ubuntu modified driver
can then be replaced with this original driver to enable the use of these emulators on this
distribution.

Building this driver should be as simple as typing the commnad 'make' in the directory containing
these sources and the make file.  The result should be a kernel module named ti_usb_3410_5052.ko

Also included in this directory is a very simple script file (reload) which will replace the running 
module with this newly built one.  To execute the script, use the following command:

   source ./reload

This will only replace the standard module until the next system restart.  A more permanent solution
is to replace the standard module file with the new one.  The module file is located in the following
directory:

   /lib/modules/2.6.24-16-generic/kernel/drivers/usb/serial/ti_usb_3410_5052.ko

The newly built module file can be copied over this Ubuntu shipped one to replace it perminantly.
It's probably wise to make a backup before overwriting the one shipped with Ubuntu.

In addition to a working driver, there is a bit of udev magic that needs to take place in order to 
get these drivers to create a device file (like /dev/ttyUSB0) when inserted.  This is well documented
elsewhere, but also included in this directory is a udev rule and script which can be used.

To install this rule, use the following commands:

   sudo cp 40-ti-usb-3410-5052.rules /etc/udev/rules.d
   sudo mkdir -p /etc/udev/scripts
   sudo cp msp430_init /etc/udev/scripts

Good luck,

Steve Glow
sglow@embeddedintelligence.com
